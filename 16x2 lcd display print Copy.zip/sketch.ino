#include <LiquidCrystal.h>

     // using 16x2 lcd display in ESP32 bord

LiquidCrystal lcd(18,5,0,4,16,17); // esp32 port number 18-RS pin, 5-E pin

void setup(){
  lcd.begin(16,2);
  lcd.setCursor(2,1);       // setCursor(colum,row)
  lcd.print("Rocky Roy");   // print Rocky Roy
  delay(5000);              // 5s stay
  lcd.clear();              // after 5s then clear display
}

void loop(){
  lcd.setCursor(4,0);      // 3 number colum 0 number row
  lcd.print("Hello");      // print Hello
}